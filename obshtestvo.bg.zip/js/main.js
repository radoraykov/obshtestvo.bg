$(function() {
    $('#content, a.contact').addClass('visible')
})
